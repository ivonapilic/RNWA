﻿using college_database_mvc.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace college_database_mvc.Controllers
{
    public class StudentsController : Controller
    {
        college_databaseContext _db;
        public StudentsController(college_databaseContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            List<Student> Students = _db.Students.ToList();
            return View("Index", Students);
        }
        public IActionResult Izbrisi(int id)
        {
            _db.Students.Remove(_db.Students.Find(id));
            _db.SaveChanges();
            return Redirect("/Students/Index");
        }
        public IActionResult Insert()
        {
            return View("Insert");
        }
        public IActionResult InsertSave(string first_name, string last_name, int department_id, string phone, DateTime admission_date, int cet_marks )
        {
            Student novi = new Student() { FirstName = first_name, LastName = last_name, DepartmentId = department_id, Phone = phone, AdmissionDate = admission_date, CetMarks = cet_marks };
            _db.Students.Add(novi);
            _db.SaveChanges();
            return Redirect("/Students/Index");
        }
        public IActionResult Uredi(int id)
        {
            Student Model = _db.Students.Find(id);
            return View("Uredi", Model);

        }
        public IActionResult UrediSave(int stu, string first_name, string last_name, int department_id, string phone, DateTime admission_date, int cet_marks)
        {
            var obj = _db.Students.Find(stu);
            obj.FirstName = first_name;
            obj.LastName = last_name;
            obj.DepartmentId= department_id;
            obj.Phone = phone;
            obj.AdmissionDate = admission_date;
            obj.CetMarks = cet_marks;
            _db.SaveChanges();
            return Redirect("/Students/Index");
        }
    }
}
