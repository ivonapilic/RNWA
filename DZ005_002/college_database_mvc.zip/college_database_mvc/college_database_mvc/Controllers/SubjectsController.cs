﻿using college_database_mvc.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace college_database_mvc.Controllers
{
    public class SubjectsController : Controller
    {
        college_databaseContext _db;
        public SubjectsController(college_databaseContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            List<Subject> Subjects = _db.Subjects.ToList();
            return View("Index", Subjects);
        }
        public IActionResult Izbrisi(int id)
        {
            _db.Subjects.Remove(_db.Subjects.Find(id));
            _db.SaveChanges();
            return Redirect("/Subjects/Index");
        }
        public IActionResult Insert()
        {
            return View("Insert");
        }
        public IActionResult InsertSave(int department_id, int start_date, int end_date, string name, int faculty_id)
        {
            Subject novi = new Subject() { DepartmentId = department_id, StartDate = start_date, EndDate = end_date ,Name = name, FacultyId = faculty_id};
            _db.Subjects.Add(novi);
            _db.SaveChanges();
            return Redirect("/Subjects/Index");
        }
        public IActionResult Uredi(int id)
        {
            Subject Model = _db.Subjects.Find(id);
            return View("Uredi", Model);

        }
        public IActionResult UrediSave(int id, int department_id, int start_date, int end_date, string name, int faculty_id)
        {
            var obj = _db.Subjects.Find(id);
            obj.DepartmentId = department_id;
            obj.StartDate = start_date;
            obj.EndDate = end_date;
            obj.Name = name;
            obj.FacultyId = faculty_id;
            _db.SaveChanges();
            return Redirect("/Subjects/Index");
        }
    }
}