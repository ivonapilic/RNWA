﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using college_database_mvc.Models;

namespace college_database_mvc.Controllers
{
    public class MarksController : Controller
    {
        college_databaseContext _db;
        public MarksController(college_databaseContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            List<Mark> Lista = _db.Marks.ToList();
            return View("Index",Lista);
        }
        public IActionResult Izbrisi(int id)
        {
            _db.Students.RemoveRange(_db.Students.Where(a => a.CetMarks == id).ToList());
            _db.Marks.Remove(_db.Marks.Find(id));
            _db.SaveChanges();
            return Redirect("/Marks/Index");


            var listmarks = _db.Marks.Where(a => a.SubjectId == id).ToList();
            foreach (var item in listmarks)
            {
                _db.Students.RemoveRange(_db.Students.Where(a => a.CetMarks == item.Id).ToList());
            }
            _db.Marks.RemoveRange(listmarks);
            _db.Subjects.Remove(_db.Subjects.Find(id));
        }
        public IActionResult Insert()
        {
            return View("Insert");
        }
        public IActionResult InsertSave(int student_roll_num, int subject_id, int marks)
        {
            Mark M = new Mark() { StudentRollNum = student_roll_num, SubjectId = subject_id, Marks = marks };
            _db.Marks.Add(M);
            _db.SaveChanges();
            return Redirect("/Marks/Index");
            
        }
        public IActionResult Uredi(int id)
        {
            Mark M = _db.Marks.Find(id);
            return View("Uredi", M);
        }
        public IActionResult UrediSave(int id, int student_roll_num, int subject_id, int marks)
        {
            var obj = _db.Marks.Find(id);
            obj.Id = id;
            obj.StudentRollNum = student_roll_num;
            obj.SubjectId = subject_id;
            obj.Marks = marks;
            _db.SaveChanges();
            return Redirect("/Marks/Index");
        }
    }
}
